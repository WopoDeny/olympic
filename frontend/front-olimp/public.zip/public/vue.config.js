module.exports = {
    devServer: {
        proxy: 'https://oauth.yandex.ru/'
    }
}